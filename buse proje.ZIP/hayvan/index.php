<?php 
include 'bağlan.php'; 
include 'üstmenü.php'; 

// Veritabanı Sorguları
$son_ilanlar = $conn->query("SELECT * FROM ilanlar WHERE durum = 'Açık' ORDER BY acil_durum DESC, id DESC LIMIT 3");
$toplam_data = $conn->query("SELECT COUNT(id) as toplam FROM ilanlar")->fetch_assoc();
$kedi_data = $conn->query("SELECT COUNT(id) as toplam FROM ilanlar WHERE tur = 'Kedi'")->fetch_assoc();
$kopek_data = $conn->query("SELECT COUNT(id) as toplam FROM ilanlar WHERE tur = 'Köpek'")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Patili Evler | Onların Kahramanı Ol</title>
    <style>
        body { background-color: #fcfaff; overflow-x: hidden; }
        
        /* 1. ÜSTTEKİ DÖNEN VE BÜYÜYEN YUVARLAK EFEKTİ */
        .hero-section {
            position: relative;
            padding: 100px 0;
            background: #6f42c1;
            color: white;
            overflow: hidden;
            border-radius: 0 0 80px 80px;
        }
        .hero-section::before {
            content: "";
            position: absolute;
            top: 50px;
            right: -100px;
            width: 450px;
            height: 450px;
            background: radial-gradient(circle, rgba(162, 155, 254, 0.7), rgba(111, 66, 193, 0));
            border-radius: 50%;
            z-index: 1;
            animation: rotateAndPulse 12s ease-in-out infinite alternate;
        }
        @keyframes rotateAndPulse {
            0% { transform: scale(1) rotate(0deg); }
            50% { transform: scale(1.4) rotate(180deg) translateX(30px); }
            100% { transform: scale(1) rotate(360deg); }
        }
        .hero-content { position: relative; z-index: 10; }

        /* 2. ARADIĞIN "BİZ KİMİZ" VE KEDİ BLOĞU */
        .who-we-are {
            background: white;
            padding: 80px 0;
            margin-top: 50px;
            border-radius: 50px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.03);
        }
        .cat-img-box {
            position: relative;
            text-align: center;
        }
        .cat-img-box img {
            max-width: 100%;
            border-radius: 30px;
            /* Hafif yuvarlak ve sağa sola büyüme animasyonu buna da eklenebilir */
            transition: 0.5s;
        }

        /* Diğer Tasarımlar */
        .stat-box { background: white; padding: 40px; border-radius: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border-top: 6px solid #6f42c1; text-align: center; }
        .pet-card { border: none; border-radius: 30px; transition: 0.4s; background: white; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); height: 100%; }
        .pet-card:hover { transform: translateY(-10px); }
    </style>
</head>
<body>

    <section class="hero-section">
        <div class="container hero-content">
            <div class="row align-items-center">
                <div class="col-lg-7 text-lg-start text-center">
                    <h1 class="display-3 fw-bold mb-4 animate__animated animate__fadeInLeft">Bir Can Kurtar, <br>Dünya Değişsin!</h1>
                    <p class="lead mb-5 opacity-75">Sıcak bir yuva bekleyen patili dostlarımıza bugün bir şans ver.</p>
                    <div class="d-flex justify-content-lg-start justify-content-center gap-3">
                        <a href="ilanara.php" class="btn btn-light btn-lg rounded-pill px-5 fw-bold text-primary shadow">Sahiplen</a>
                        <a href="ilanver.php" class="btn btn-outline-light btn-lg rounded-pill px-5">İlan Ver</a>
                    </div>
                </div>
                <div class="col-lg-5 text-center">
                    <img src="anasayfa.png" class="img-fluid animate__animated animate__zoomIn" style="filter: drop-shadow(0 20px 30px rgba(0,0,0,0.2)); border-radius:30px;">
                </div>
            </div>
        </div>
    </section>

    <div class="container py-5 mt-5">
        <h2 class="fw-bold mb-5" style="border-left: 8px solid #6f42c1; padding-left: 15px;">Yeni Yuva Arayanlar</h2>
        <div class="row">
            <?php while($ilan = $son_ilanlar->fetch_assoc()): ?>
            <div class="col-md-4 mb-4">
                <div class="pet-card">
                    <?php if($ilan['acil_durum'] == 1): ?>
                        <div class="badge bg-danger position-absolute m-3 p-2 px-3 animate__animated animate__flash animate__infinite" style="z-index:20; border-radius:50px;">ACİL YUVA!</div>
                    <?php endif; ?>
                    <img src="images/<?php echo $ilan['resim']; ?>" style="height:300px; width:100%; object-fit:cover;">
                    <div class="card-body p-4 text-center">
                        <h4 class="fw-bold mb-3"><?php echo $ilan['baslik']; ?></h4>
                        <a href="ilan-detay.php?id=<?php echo $ilan['id']; ?>" class="btn text-white w-100 rounded-pill py-2" style="background:#6f42c1;">Hikayesini Gör</a>
                    </div>
                </div>
            </div>
            
            <?php endwhile; ?>
        </div>
    </div>
 <div class="container py-5">
        <div class="row text-center g-4">
            <div class="col-md-4"><div class="stat-box"><h2><?php echo $toplam_data['toplam']; ?></h2><p class="mb-0 fw-bold text-muted">TOPLAM İLAN</p></div></div>
            <div class="col-md-4"><div class="stat-box"><h2><?php echo $kedi_data['toplam']; ?></h2><p class="mb-0 fw-bold text-muted">KEDİ 🐱</p></div></div>
            <div class="col-md-4"><div class="stat-box"><h2><?php echo $kopek_data['toplam']; ?></h2><p class="mb-0 fw-bold text-muted">KÖPEK 🐶</p></div></div>
        </div>
    </div>
    <section class="container who-we-are mb-5">
        <div class="row align-items-center p-4">
            <div class="col-lg-6 cat-img-box">
                <img src="anasayfa2.png" alt="Biz Kimiz Kedi" class="img-fluid shadow-sm">
            </div>
            <div class="col-lg-6 ps-lg-5 mt-4 mt-lg-0">
                <h2 class="fw-bold mb-4">Biz <span style="color: #6f42c1;">Kimiz?</span></h2>
                <p class="text-muted lead mb-4">
                    Patili Evler, sahipsiz dostlarımızın sıcak bir yuvaya kavuşması için gönüllü olarak çalışan bir platformdur. 
                    Amacımız, her patili dostumuzun hak ettiği sevgiyi göreceği güvenli bir liman bulmasını sağlamaktır.
                </p>
                <div class="row g-3">
                    <div class="col-6"><i class="fas fa-check-circle text-success me-2"></i> %100 Ücretsiz</div>
                    <div class="col-6"><i class="fas fa-check-circle text-success me-2"></i> Güvenilir İlanlar</div>
                    <div class="col-6"><i class="fas fa-check-circle text-success me-2"></i> Hızlı İletişim</div>
                    <div class="col-6"><i class="fas fa-check-circle text-success me-2"></i> Gönüllü Ekip</div>
                </div>
                <a href="hakkımızda.php" class="btn btn-primary btn-lg rounded-pill mt-5 px-5" style="background:#6f42c1; border:none;">Daha Fazla Bilgi</a>
            </div>
        </div>
    </section>

    

    <?php include 'altbilgi.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
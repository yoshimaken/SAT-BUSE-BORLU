<?php
session_start();
include 'bağlan.php';

if (!isset($_SESSION['admin_yetki'])) { header("Location: admin.php"); exit(); }

if (isset($_GET['sil'])) {
    $id = intval($_GET['sil']);
    $conn->query("DELETE FROM ilanlar WHERE id = $id");
    header("Location: admin_panel.php");
}

$ilanlar = $conn->query("SELECT * FROM ilanlar ORDER BY acil_durum DESC, id DESC");
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Patili Evler | Yönetim</title>
    <style>
        body { background: #f8f9fa; font-family: 'Poppins', sans-serif; }
        .admin-nav { background: #6f42c1; color: white; padding: 15px 0; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .settings-btn { background: rgba(255,255,255,0.2); border: none; color: white; border-radius: 50%; width: 40px; height: 40px; transition: 0.3s; }
        .settings-btn:hover { background: rgba(255,255,255,0.4); transform: rotate(90deg); }
        .card-stat { border: none; border-radius: 20px; padding: 25px; box-shadow: 0 5px 20px rgba(0,0,0,0.05); background: white; }
    </style>
</head>
<body>

    <nav class="admin-nav mb-5">
        <div class="container d-flex justify-content-between align-items-center">
            <h4 class="mb-0 fw-bold"><i class="fas fa-shield-alt me-2"></i> Yönetim Paneli</h4>
            <div class="dropdown">
                <button class="settings-btn" data-bs-toggle="dropdown"><i class="fas fa-cog"></i></button>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0" style="border-radius: 15px;">
                    <li><a class="dropdown-item" href="index.php"><i class="fas fa-home me-2"></i> Siteye Dön</a></li>
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#passModal"><i class="fas fa-key me-2"></i> Şifre Bilgisi</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="cikis.php"><i class="fas fa-sign-out-alt me-2"></i> Çıkış Yap</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row mb-5 text-center">
            <div class="col-md-4"><div class="card-stat"><h5>Toplam İlan</h5><h2 class="fw-bold mb-0"><?php echo $ilanlar->num_rows; ?></h2></div></div>
            <div class="col-md-4"><div class="card-stat"><h5>Durum</h5><h2 class="fw-bold mb-0 text-success">Online</h2></div></div>
            <div class="col-md-4"><div class="card-stat"><h5>Admin</h5><h2 class="fw-bold mb-0">Local</h2></div></div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 p-4">
            <h4 class="fw-bold mb-4">Yayındaki İlanlar</h4>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr><th>Görsel</th><th>Başlık</th><th>Tür/Cins</th><th>Durum</th><th class="text-end">İşlem</th></tr>
                    </thead>
                    <tbody>
                        <?php while($r = $ilanlar->fetch_assoc()): ?>
                        <tr>
                            <td><img src="images/<?php echo $r['resim']; ?>" width="55" height="55" style="border-radius:10px; object-fit:cover;"></td>
                            <td><div class="fw-bold"><?php echo $r['baslik']; ?></div><small class="text-muted"><?php echo $r['sehir']; ?></small></td>
                            <td><?php echo $r['tur']; ?> / <?php echo $r['cins']; ?></td>
                            <td><?php echo ($r['acil_durum'] == 1) ? '<span class="badge bg-danger rounded-pill">ACİL</span>' : '<span class="badge bg-secondary rounded-pill">Normal</span>'; ?></td>
                            <td class="text-end">
                                <a href="admin_panel.php?sil=<?php echo $r['id']; ?>" class="btn btn-outline-danger btn-sm rounded-pill px-3" onclick="return confirm('İlanı kalıcı olarak siliyorsunuz?')"><i class="fas fa-trash"></i> Sil</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="passModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0" style="border-radius: 20px;">
                <div class="modal-body text-center p-5">
                    <i class="fas fa-lock-open fa-3x text-warning mb-3"></i>
                    <p class="text-muted">Aktif Admin Şifreniz:</p>
                    <h1 class="fw-bold text-primary">123</h1>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
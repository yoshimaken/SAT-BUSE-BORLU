<?php 
include 'bağlan.php'; 
include 'üstmenü.php'; 

// Filtreleme Mantığı
$where = "WHERE durum = 'Açık'";
$tur_filtre = $_GET['tur'] ?? '';
$sehir_filtre = $_GET['sehir'] ?? '';

if($tur_filtre != "") {
    $tur = $conn->real_escape_string($tur_filtre);
    $where .= " AND tur = '$tur'";
}
if($sehir_filtre != "") {
    $sehir = $conn->real_escape_string($sehir_filtre);
    $where .= " AND sehir = '$sehir'";
}

$ilanlar = $conn->query("SELECT * FROM ilanlar $where ORDER BY acil_durum DESC, id DESC");
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>İlanları Keşfet | Patili Evler</title>
    <style>
        body { background-color: #f8f7ff; }
        
        /* MOR FİLTRELEME KUTUSU */
        .filter-box {
            background: #6f42c1;
            border-radius: 30px;
            padding: 20px 30px;
            margin-top: -40px; /* Hero'ya yakın durması için */
            box-shadow: 0 15px 40px rgba(111, 66, 193, 0.25);
            z-index: 100;
            position: relative;
        }

        .filter-btn {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 50px;
            padding: 10px 25px;
            font-weight: 600;
            transition: 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .filter-btn:hover, .filter-btn.active {
            background: white;
            color: #6f42c1;
            transform: translateY(-3px);
        }

        .city-select {
            background: white;
            color: #6f42c1;
            border-radius: 50px;
            padding: 10px 20px;
            border: none;
            font-weight: 600;
            outline: none;
            cursor: pointer;
        }

        /* Kart Tasarımı */
        .pet-card { border: none; border-radius: 30px; transition: 0.4s; background: white; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.05); }
        .pet-card:hover { transform: translateY(-10px); box-shadow: 0 20px 40px rgba(111, 66, 193, 0.15); }
    </style>
</head>
<body>

<div class="container py-5">
    
    <div class="filter-box mb-5">
        <div class="row align-items-center">
            <div class="col-md-8 d-flex gap-2 flex-wrap justify-content-center justify-content-md-start">
                <a href="ilanara.php" class="filter-btn <?php echo ($tur_filtre == '') ? 'active' : ''; ?>">
                    <i class="fas fa-paw me-1"></i> Tüm İlanlar
                </a>
                <a href="ilanara.php?tur=Kedi&sehir=<?php echo $sehir_filtre; ?>" class="filter-btn <?php echo ($tur_filtre == 'Kedi') ? 'active' : ''; ?>">
                    <i class="fas fa-cat me-1"></i> Kediler
                </a>
                <a href="ilanara.php?tur=Köpek&sehir=<?php echo $sehir_filtre; ?>" class="filter-btn <?php echo ($tur_filtre == 'Köpek') ? 'active' : ''; ?>">
                    <i class="fas fa-dog me-1"></i> Köpekler
                </a>
            </div>
            
            <div class="col-md-4 mt-3 mt-md-0 text-center text-md-end">
                <form method="GET" action="ilanara.php" class="d-inline-flex align-items-center gap-2">
                    <input type="hidden" name="tur" value="<?php echo $tur_filtre; ?>">
                    <span class="text-white small fw-bold">Şehir:</span>
                    <select name="sehir" class="city-select" onchange="this.form.submit()">
                        <option value="">Hepsini Gör</option>
                        <option value="İstanbul" <?php echo ($sehir_filtre == 'İstanbul') ? 'selected' : ''; ?>>İstanbul</option>
                        <option value="Ankara" <?php echo ($sehir_filtre == 'Ankara') ? 'selected' : ''; ?>>Ankara</option>
                        <option value="İzmir" <?php echo ($sehir_filtre == 'İzmir') ? 'selected' : ''; ?>>İzmir</option>
                        <option value="Bursa" <?php echo ($sehir_filtre == 'Bursa') ? 'selected' : ''; ?>>Bursa</option>
                        <option value="Antalya" <?php echo ($sehir_filtre == 'Antalya') ? 'selected' : ''; ?>>Antalya</option>
                    </select>
                </form>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-4 px-3">
        <h3 class="fw-bold text-dark m-0">
            <?php 
                if($tur_filtre == 'Kedi') echo "🐱 Yuva Arayan Kediler";
                elseif($tur_filtre == 'Köpek') echo "🐶 Yuva Arayan Köpekler";
                else echo "🐾 Tüm Patili Dostlarımız";
            ?>
        </h3>
        <span class="badge bg-white text-primary border px-3 py-2 rounded-pill fw-bold">
            <?php echo $ilanlar->num_rows; ?> İlan Bulundu
        </span>
    </div>

    <div class="row">
        <?php if($ilanlar->num_rows > 0): ?>
            <?php while($row = $ilanlar->fetch_assoc()): ?>
            <div class="col-md-4 mb-4">
                <div class="pet-card">
                    <?php if($row['acil_durum'] == 1): ?>
                        <div class="badge bg-danger position-absolute m-3 p-2 px-3 animate__animated animate__flash animate__infinite" style="z-index:10; border-radius:50px;">⚠️ ACİL YUVA!</div>
                    <?php endif; ?>

                    <img src="images/<?php echo $row['resim']; ?>" class="w-100" style="height:280px; object-fit:cover;">
                    
                    <div class="card-body p-4 text-center">
                        <span class="badge rounded-pill mb-2" style="background:#efebf7; color:#6f42c1;"><?php echo $row['tur']; ?> / <?php echo $row['cins']; ?></span>
                        <h4 class="fw-bold mb-3"><?php echo $row['baslik']; ?></h4>
                        <p class="text-muted small mb-4"><i class="fas fa-map-marker-alt text-danger"></i> <?php echo $row['sehir']; ?></p>
                        
                        <a href="ilan-detay.php?id=<?php echo $row['id']; ?>" class="btn text-white w-100 rounded-pill py-2 fw-bold shadow-sm" style="background:#6f42c1;">
                            Hikayesini Gör <i class="fas fa-paw ms-1"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-search fa-4x text-muted mb-3"></i>
                <h3 class="text-muted">Aradığınız kriterlere uygun ilan bulunamadı.</h3>
                <a href="ilanara.php" class="btn btn-outline-primary rounded-pill px-4 mt-3">Tümünü Göster</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'altbilgi.php'; ?>
</body>
</html>
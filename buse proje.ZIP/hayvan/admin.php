<?php
session_start();
// Localhost kontrolü (Sadece yerel erişim izni)
if ($_SERVER['REMOTE_ADDR'] !== '127.0.0.1' && $_SERVER['REMOTE_ADDR'] !== '::1') {
    die("Bu panele sadece bu bilgisayardan erişilebilir.");
}

if (isset($_POST['login'])) {
    $sifre = "123"; // Şifreyi 123 olarak güncelledik
    if ($_POST['password'] == $sifre) {
        $_SESSION['admin_yetki'] = true;
        header("Location: admin_panel.php");
        exit();
    } else {
        $hata = "Hatalı şifre!";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Admin Giriş</title>
    <style>
        body { background: #f4f7f6; display: flex; align-items: center; justify-content: center; height: 100vh; }
        .login-card { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); width: 350px; }
    </style>
</head>
<body>
    <div class="login-card">
        <h3 class="text-center mb-4" style="color:#6f42c1;">Admin Girişi</h3>
        <?php if(isset($hata)) echo "<div class='alert alert-danger'>$hata</div>"; ?>
        <form method="POST">
            <input type="password" name="password" class="form-control mb-3" placeholder="Şifre" required>
            <button type="submit" name="login" class="btn w-100 text-white" style="background:#6f42c1;">Giriş Yap</button>
        </form>
    </div>
</body>
</html>
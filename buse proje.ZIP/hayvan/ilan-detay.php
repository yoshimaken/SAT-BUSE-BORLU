<?php 
include 'bağlan.php'; 
include 'üstmenü.php'; 

$id = intval($_GET['id']);
$ilan = $conn->query("SELECT * FROM ilanlar WHERE id = $id")->fetch_assoc();
?>

<div class="container py-5">
    <div class="row bg-white rounded-5 shadow-lg overflow-hidden border">
        <div class="col-md-6 p-0">
            <img src="images/<?php echo $ilan['resim']; ?>" class="img-fluid h-100 w-100" style="object-fit:cover; min-height:500px;">
        </div>
        
        <div class="col-md-6 p-5 d-flex flex-column justify-content-center">
            <span class="badge mb-3 align-self-start" style="background:#efebf7; color:#6f42c1; padding:10px 20px; border-radius:50px;">
                <?php echo $ilan['tur']; ?> / <?php echo $ilan['cins']; ?>
            </span>
            
            <h1 class="fw-bold text-dark mb-2"><?php echo $ilan['baslik']; ?></h1>
            <p class="text-muted mb-4"><i class="fas fa-map-marker-alt"></i> <?php echo $ilan['sehir']; ?></p>
            
            <h5 class="fw-bold mb-2">Hikayesi</h5>
            <p class="text-muted"><?php echo $ilan['aciklama']; ?></p>

            <hr class="my-4"> <div class="d-flex align-items-center gap-3">
                <i class="fas fa-phone-alt text-primary fs-4"></i> <span id="telNumara" class="fs-4 fw-bold text-dark"><?php echo $ilan['telefon']; ?></span> <button onclick="numarayiKopyala()" class="btn btn-sm btn-light border rounded-pill px-3" id="copyBtn">
                    <i class="far fa-copy"></i> Kopyala </button>
            </div>
        </div>
    </div>
</div>

<script>
function numarayiKopyala() {
    var numara = document.getElementById("telNumara").innerText;
    navigator.clipboard.writeText(numara).then(function() {
        var btn = document.getElementById("copyBtn");
        btn.innerHTML = '<i class="fas fa-check"></i> Kopyalandı';
        setTimeout(function(){
            btn.innerHTML = '<i class="far fa-copy"></i> Kopyala';
        }, 1500);
    });
}
</script>

<?php include 'altbilgi.php'; ?>
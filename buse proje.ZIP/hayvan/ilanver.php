<?php include 'üstmenü.php'; ?>

<div class="form-wrapper" style="background: url('anasayfa.png') fixed center; background-size: cover; min-height: 100vh; padding: 100px 20px; display: flex; justify-content: center; align-items: center;">
    <div class="form-card" style="background: rgba(255,255,255,0.92); backdrop-filter: blur(10px); padding: 40px; border-radius: 40px; width: 100%; max-width: 650px; box-shadow: 0 25px 50px rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.3);">
        <h2 class="text-center mb-4" style="color: #6f42c1; font-weight: 800; letter-spacing: -1px;">Yeni Bir İlan Paylaş</h2>
        
        <form action="ilan.kaydet.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label fw-bold">İlan Başlığı</label>
                <input type="text" class="form-control rounded-pill px-3" name="baslik" placeholder="Örn: Yuva arayan dünya tatlısı" required>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Ana Tür</label>
                    <select class="form-select rounded-pill px-3" name="tur" id="anaTur" onchange="cinsGuncelle()" required>
                        <option value="" selected disabled>Seçiniz...</option>
                        <option value="Kedi">Kedi 🐱</option>
                        <option value="Köpek">Köpek 🐶</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Cins / Irk</label>
                    <select class="form-select rounded-pill px-3" name="cins" id="cinsSecimi" required disabled>
                        <option value="">Önce tür seçin</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Şehir</label>
                    <select class="form-select rounded-pill px-3" name="sehir" required>
                        <option value="İstanbul">İstanbul</option>
                        <option value="Ankara">Ankara</option>
                        <option value="İzmir">İzmir</option>
                        <option value="Bursa">Bursa</option>
                        <option value="Antalya">Antalya</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold text-primary">Telefon No</label>
                    <input type="text" class="form-control rounded-pill px-3" name="telefon" placeholder="05XX XXX XX XX" required>
                </div>
            </div>

            <div class="mb-3 p-3 rounded-4" style="background: rgba(220, 53, 69, 0.05); border: 1px dashed #dc3545;">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="acil_durum" value="1" id="acilCheck">
                    <label class="form-check-label fw-bold text-danger" for="acilCheck">
                        ⚠️ BU ACİL BİR İLANDIR! (Sokakta kalma riski var)
                    </label>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Fotoğraf Seç</label>
                <input type="file" class="form-control rounded-pill px-3" name="resim" accept="image/*" required>
            </div>

            <div class="mb-4">
                <label class="form-label fw-bold">Dostumuzun Hikayesi</label>
                <textarea class="form-control rounded-4" name="aciklama" rows="3" placeholder="Onun hakkında bilgi verin..." required></textarea>
            </div>

            <button type="submit" class="btn w-100 py-3 shadow-lg" style="background: #6f42c1; color: white; font-weight: 700; border-radius: 50px; border: none;">İlanı Yayınla</button>
        </form>
    </div>
</div>

<script>
function cinsGuncelle() {
    const tur = document.getElementById('anaTur').value;
    const cinsBox = document.getElementById('cinsSecimi');
    cinsBox.innerHTML = "";
    cinsBox.disabled = false;

    let secenekler = [];
    if(tur === "Kedi") {
        secenekler = ["Tekir", "Siyam", "Van Kedisi", "Ankara Kedisi", "Scottish Fold"];
    } else if(tur === "Köpek") {
        secenekler = ["Golden Retriever", "Alman Kurdu", "Pug", "Sivas Kangalı", "Terrier"];
    }

    secenekler.forEach(c => {
        let opt = document.createElement('option');
        opt.value = c; opt.innerText = c;
        cinsBox.appendChild(opt);
    });
}
</script>
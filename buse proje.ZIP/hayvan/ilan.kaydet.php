<?php
include 'bağlan.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Formdan gelen verileri al
    $baslik = $conn->real_escape_string($_POST['baslik']);
    $tur = $conn->real_escape_string($_POST['tur']);
    $cins = $conn->real_escape_string($_POST['cins']);
    $sehir = $conn->real_escape_string($_POST['sehir']);
    $aciklama = $conn->real_escape_string($_POST['aciklama']);
    $telefon = $conn->real_escape_string($_POST['telefon']); // Telefon verisi alınıyor
    
    // Acil durum checkbox kontrolü
    $acil_durum = isset($_POST['acil_durum']) ? 1 : 0;

    // Resim Yükleme İşlemi
    $target_dir = "images/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $resim_adi = time() . "_" . basename($_FILES["resim"]["name"]);
    $target_file = $target_dir . $resim_adi;

    if (move_uploaded_file($_FILES["resim"]["tmp_name"], $target_file)) {
        // SQL Sorgusu (telefon alanı dahil edildi)
        $sql = "INSERT INTO ilanlar (baslik, tur, cins, sehir, resim, aciklama, acil_durum, telefon, durum) 
                VALUES ('$baslik', '$tur', '$cins', '$sehir', '$resim_adi', '$aciklama', '$acil_durum', '$telefon', 'Açık')";
        
        if ($conn->query($sql) === TRUE) {
            // Kayıt başarılıysa ana sayfaya git
            header("Location: index.php");
            exit();
        } else {
            echo "Veritabanı Hatası: " . $conn->error;
        }
    } else {
        echo "Resim yüklenirken bir hata oluştu.";
    }
}
?>
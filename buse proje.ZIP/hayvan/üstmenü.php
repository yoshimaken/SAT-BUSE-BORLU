<link rel="icon" type="image/png" href="images/logo.png"> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

<nav class="custom-navbar fixed-top">
    <div class="nav-brand-container">
        <a class="nav-brand" href="index.php">PATİLİ EVLER</a>
    </div>

    <div class="nav-links-center">
        <a href="index.php" class="menu-link">Ana Sayfa</a>
        <a href="hakkımızda.php" class="menu-link">Hakkımızda</a>
        <a href="ilanara.php" class="menu-link">İlanlara Bak</a>
        <a href="ilanver.php" class="menu-link">İlan Ver</a>
    </div>

    <div class="nav-admin-right">
        <?php if($_SERVER['REMOTE_ADDR'] == '127.0.0.1' || $_SERVER['REMOTE_ADDR'] == '::1'): ?>
            <a href="admin.php" class="menu-link admin-entry-btn">
                Admin Paneline Giriş Yap <i class="fas fa-cog ms-1"></i>
            </a>
        <?php endif; ?>
    </div>
</nav>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body { 
        padding-top: 90px; 
        font-family: 'Poppins', sans-serif;
        background-color: #fcfaff;
        /* PATİ İZİ ARKA PLANI */
        background-image: url('https://www.transparenttextures.com/patterns/claws.png');
        background-attachment: fixed;
    }

    .custom-navbar {
        background-color: #ffffff;
        height: 90px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 40px;
        box-shadow: 0 2px 15px rgba(0,0,0,0.05);
        z-index: 1000;
    }

    .nav-brand-container { flex: 1; }
    .nav-brand { color: #6f42c1 !important; font-weight: 900; font-size: 1.6rem; text-decoration: none; }

    .nav-links-center { flex: 2; display: flex; justify-content: center; gap: 10px; }

    .nav-admin-right { flex: 1; display: flex; justify-content: flex-end; }

    .menu-link {
        color: #6f42c1 !important;
        font-weight: 700;
        font-size: 0.95rem;
        text-decoration: none;
        padding: 10px 18px;
        border-radius: 12px;
        transition: 0.3s all ease;
        white-space: nowrap;
    }

    .menu-link:hover { 
        background-color: #6f42c1 !important; 
        color: #ffffff !important; 
    }

    .admin-entry-btn {
        background-color: rgba(111, 66, 193, 0.08) !important;
        border: 1.5px dashed #6f42c1;
        font-size: 0.85rem;
    }
    
    .admin-entry-btn:hover i {
        animation: fa-spin 2s infinite linear;
    }

    @media (max-width: 991px) {
        .nav-links-center, .nav-admin-right { display: none; }
    }
</style>